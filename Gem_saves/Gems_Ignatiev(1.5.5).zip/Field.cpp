#include "Header.h"

int Field::getSize()
{
	return size;
}

void Field::ToMatCoords(int disp_x, int disp_y, int* mat_x, int* mat_y)
{
	*mat_y = (disp_x - startx) / size;
	*mat_x = (disp_y - starty) / size;
	return;
}

/*

void Field::ToDispCoords(int x, int y, int* new_x, int* new_y)
{
	*new_x = startx + size * x + size/2;
	*new_y = starty + size * y + size/2;							//TODO: � ���������� ����������
	return;
}

void Field::GemFall(int x_t, int y_t)
{
	int i = x_t + 1;
		
	while( i < FieldSize && GemsField[i][y_t] == NULL)
	{
		i++;
	}
	   
	i -= (x_t+1);  //Fall while you can
	
	if (i > 0)
	{
		GemsField[i+x_t][y_t] = GemsField[x_t][y_t];
		GemsField[i + x_t][y_t]->mat_x = i + x_t;
		GemsField[i + x_t][y_t]->mat_y = y_t;
		GemsField[x_t][y_t] = NULL;
	}
	
	return;
}

void Field::FixField()
{
	int i = 0;
	int new_x, new_y;
	GemType new_type;

	for (i = FieldSize - 2; i >= 0; i--)
	{
		for (int j = 0; j < FieldSize; j++)
		{
			if (GemsField[i][j] != NULL)
				GemFall(i, j);
		}
	}
	
	for (i = FieldSize - 1; i>=0; i--)
	{
		for (int j = 0; j < FieldSize; j++)
		{
			if (GemsField[i][j] == NULL)
			{
				ToDispCoords(-(FieldSize-i)*size / 32 - j*size/32, j, &new_x, &new_y);        //TODO: ADD RAND
				
				new_type = (GemType)(rand() % 7);
				GemsField[i][j] = new Gem(new_x, new_y, i, j, new_type);
				GemsField[i][j]->speedx = 2.0*BonusMoveSpeed;
			}
		}
	}

	//printf("\n Fix Complete!\n");
	
	return;
}

*/

void Field::FieldUpdate()
{	   
	//GemsUpdate
	for (int i = 0; i < FieldSize; i++)
	{
		for (int j = 0; j < FieldSize; j++)
		{
			if (GemsField[i][j] != NULL)
			{
				GemsField[i][j]->Move(startx,starty);		
			}
		}
	}

	//BonusesUpdate
	for (int i = 0; i < FieldSize*FieldSize; i++)
	{
		if (BonusMass[i] != NULL)
		{
			BonusMass[i]->BonusMove(startx, starty);

			if (BonusMass[i]->speedx == 0.0 && BonusMass[i]->speedy == 0.0)
			{
				DeleteBonus(i, BonusMass[i]);
				BonusMass[i] = NULL;
			}
		}
	} 	 
	return;
}

void Field::PrintGems(RenderWindow *window)
{
	for (int i = FieldSize-1; i >=0; i--)
	{
		for (int j= FieldSize - 1; j >= 0; j--)
		{
			GemsField[i][j]->DrawGem(window);
		}
	}

	return;
}

void Field::PrintBonuses(RenderWindow *window)
{
	for (int i = FieldSize - 1; i >= 0; i--)
	{
		for (int j = FieldSize - 1; j >= 0; j--)
		{
			BonusMass[i*FieldSize + j]->DrawBonus(window);
		}
	}

	return;
}

void Field::Swap(SelectedGems *selected)
{
	Gem *temp, *F, *S;
	
	F = GemsField[selected->Fgemx][selected->Fgemy];
	S = GemsField[selected->Sgemx][selected->Sgemy];

	F->mat_x = selected->Sgemx;
	F->mat_y = selected->Sgemy;

	S->mat_x = selected->Fgemx;
	S->mat_y = selected->Fgemy;

	F->speedx = -(F->display_x - S->display_x) / size * FPS;
	F->speedy = -(F->display_y - S->display_y) / size * FPS; //TODO: kalibrowka

	S->speedx = -F->speedx;
	S->speedy = -F->speedy;					             	// Set speed
	   
	temp = GemsField[selected->Fgemx][selected->Fgemy];
	GemsField[selected->Fgemx][selected->Fgemy] = GemsField[selected->Sgemx][selected->Sgemy];
	GemsField[selected->Sgemx][selected->Sgemy] = temp;

	return;
}

bool Field::LineCheck()
{
	//For Checking
	Gem **mass = new Gem *[FieldSize*FieldSize];
	int num = 0;

	GemType cur_gem;

	int i=0;
	int count=0;
	bool ans = false;
	for (int x = 0; x < FieldSize; x++)
	{
		for (int y = 0; y < FieldSize; y++)
		{
			cur_gem = GemsField[x][y]->getType();

			if (!CheckRepeat(mass, num, GemsField[x][y]))
			{
				continue;
			}

			//vertical
			i = 0;
			count = 0;
			while ((x + i) < FieldSize && GemsField[x + i][y]->getType() == cur_gem)
			{
				count++;
				i++;
			}

			i = 1;
			while ((x - i) >= 0 && GemsField[x - i][y]->getType() == cur_gem)
			{
				count++;
				i++;
			}

			if (count >= 3)
			{
				ans = true;
				i = 0;
				while ((x - i) >= 0 && GemsField[x - i][y]->getType() == cur_gem)
				{
					if (CheckRepeat(mass, num, GemsField[x - i][y]))
					{
						mass[num] = GemsField[x - i][y];
						num++;
					}
					i++;
				}

				i = 1;
				while ((x + i) < FieldSize && GemsField[x + i][y]->getType() == cur_gem)
				{
					if (CheckRepeat(mass, num, GemsField[x + i][y]))
					{
						mass[num] = GemsField[x + i][y];
						num++;
					}
					i++;
				}
			}

			//horizontal
			i = 0;
			count = 0;
			while ((y + i) < FieldSize && GemsField[x][y + i]->getType() == cur_gem)
			{
				count++;
				i++;
			}

			i = 1;
			while ((y - i) >= 0 && GemsField[x][y - i]->getType() == cur_gem)
			{
				count++;
				i++;
			}

			if (count >= 3)
			{
				ans = true;
				i = 0;
				while ((y - i) >= 0 && GemsField[x][y - i]->getType() == cur_gem)
				{
					if (CheckRepeat(mass, num, GemsField[x][y - i]))
					{
						mass[num] = GemsField[x][y - i];
						num++;
					}
					i++;
				}

				i = 1;
				while ((y + i) < FieldSize && GemsField[x][y + i]->getType() == cur_gem)
				{
					if (CheckRepeat(mass, num, GemsField[x][y + i]))
					{
						mass[num] = GemsField[x][y + i];
						num++;
					}
					i++;
				}
			}
		}

	}
	
	for (i = 0; i < num; i++)
	{
		//printf("del %i %i %i\n", mass[i]->mat_x, mass[i]->mat_y, mass[i]->getType());
		PlayerScore += mass[i]->GetScore();
		DeleteGem(mass[i]);
	}
	   
	delete[] mass;

	return ans;
}

bool Field::CheckRepeat(Gem **mass, int num, Gem* gem)
{
	int j;
	for (j = 0; j < num; j++)
	{
		if (j < num && mass[j] == gem)
		{
			break;
		}
	}

	if (j == num)
	{
		return true;
	}
	return false;
}

/*

void Field::DeleteGem(Gem* gem)
{
	int x = gem->mat_x;
	int y = gem->mat_y;

	if (rand() % 100 >= 65)	//creating bonus
	{
		int i = 0;
		BonusType new_type = (BonusType)(rand() % 3);
		printf("%i\n", new_type);

		while (i < FieldSize*FieldSize && BonusMass[i] != NULL)
			i++;
		

		if (new_type == bomb)
			for (int j = 0; j < 4; j++)														//TODO: add rand()
				BonusMass[i] = new Bonus(gem->display_x, gem->display_y, gem->mat_x, gem->mat_y, new_type);
		else
			BonusMass[i] = new Bonus(gem->display_x, gem->display_y, gem->mat_x, gem->mat_y, new_type);
	}

	Gem* t = GemsField[gem->mat_x][gem->mat_y];
	delete t;
	GemsField[x][y] = NULL;
	FixField();
	return;
}

void Field::DeleteBonus(int i, Bonus* bonus)
{
	switch (bonus->getType())
	{
		case bomb:
		{
			if (GemsField[bonus->mat_x][bonus->mat_y] != NULL)
			{
				DeleteGem(GemsField[bonus->mat_x][bonus->mat_y]);
			}
		
			break; 
		}
		case colorchange:
		{
			GemsField[bonus->mat_x][bonus->mat_y]->setType( (GemType)( rand() % 7) );
			GemsField[bonus->mat_x][bonus->mat_y]->changeImage();
			break; 
		}
		case extrapoints:
		{
			PlayerScore+=bonus->GetScore(); 
			break; 
		}
	}

	delete bonus;
	BonusMass[i] = NULL;
	return;
}

void Field::DeleteBonuses()
{
	for (int i = 0; i < FieldSize; i++)
	{
		for (int j = 0; j < FieldSize; j++)
		{
			if (BonusMass[i*FieldSize + j] != NULL)
			{
				delete BonusMass[i*FieldSize + j];
				BonusMass[i*FieldSize + j] = NULL;
			}

		}
	}
}

void Field::DeleteAnimations()
{
	int _x, _y;

	for (int i = 0; i < FieldSize; i++)
	{
		for (int j = 0; j < FieldSize; j++)
		{
		
			if (BonusMass[i*FieldSize + j] != NULL)
			{
				ToDispCoords(BonusMass[i*FieldSize + j]->mat_x, BonusMass[i*FieldSize + j]->mat_y, &_x, &_y);
				BonusMass[i*FieldSize + j]->display_x = _x;
				BonusMass[i*FieldSize + j]->display_y = _y;
			}
		}
	}
}
*/

bool Field::AnimationPlaying()
{
	for (int i = 0; i < FieldSize; i++)
	{
		for (int j = 0; j < FieldSize; j++)
		{
			if (GemsField[i][j]->speedx != 0.0 || GemsField[i][j]->speedy != 0.0)
			{
				//printf(" %i %i %lf %lf\n", i,j, GemsField[i][j]->speedx, GemsField[i][j]->speedy);
				//printf("Wait\n");
				return true;
			}

			if (BonusMass[i*FieldSize + j] != NULL && (BonusMass[i*FieldSize + j]->speedx != 0.0 || BonusMass[i*FieldSize + j]->speedy != 0.0))
			{
				//printf(" %lf %lf\n", BonusMass[i*FieldSize + j]->speedx, BonusMass[i*FieldSize + j]->speedy);
				return true;
			}
		}
	}

	return false;

}